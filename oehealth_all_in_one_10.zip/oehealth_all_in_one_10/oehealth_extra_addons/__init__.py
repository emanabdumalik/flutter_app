# -*- coding: utf-8 -*-
##############################################################################
#    Copyright (C) 2017 oeHealth (<http://oehealth.in>). All Rights Reserved
#    oeHealth, Hospital Management Solutions
##############################################################################

import oeh_pediatrics
import oeh_icd10pcs
import oeh_surgery
import oeh_ophthalmology
import oeh_nursing
import oeh_imaging
import oeh_ntd
import oeh_evaluation_history
import oeh_medical_certificate
import oeh_walkins
import oeh_patient_call_log
import oeh_patient_medical_history
