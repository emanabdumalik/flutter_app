##############################################################################
#    Copyright (C) 2017 oeHealth (<http://oehealth.in>). All Rights Reserved
#    oeHealth, Hospital Management Solutions
##############################################################################
# -*- coding: utf-8 -*-
import oeh_medical

import oeh_evaluation
import oeh_socioeconomics
import oeh_gyneco
import oeh_lifestyle
import oeh_lab
