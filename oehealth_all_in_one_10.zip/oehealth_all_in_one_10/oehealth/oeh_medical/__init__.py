##############################################################################
#    Copyright (C) 2015 oeHealth (<http://oehealth.in>). All Rights Reserved
#    oeHealth, Hospital Management Solutions
##############################################################################

# -*- coding: utf-8 -*-
import res_partner
import product_product
import oeh_medical_healthcenters
import oeh_medical_pathology
import oeh_medical_pharmacy
import oeh_medical_medicaments
import oeh_medical_insurance
import oeh_medical_ethnic_groups
import oeh_medical_genetics
import oeh_medical
import account_invoice
import oeh_medical_inpatient

