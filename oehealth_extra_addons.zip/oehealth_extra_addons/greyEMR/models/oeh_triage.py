from odoo import api, fields, models, _
import time
import datetime


# Lab Units Management

class OeHealthTriage(models.Model):
    _name = 'oeh.medical.triage'
    _description = 'Triage'
    TRIAGE_STATES = [
        ('draft', 'Draft'),
        ('inprogress', 'In Progress'),
        ('complete', 'Complete'),
    ]
    name = fields.Char(string='Name', size=25, required=True)
    weight = fields.Integer(string="Weight")
    state = fields.Selection(TRIAGE_STATES,string='Triage State',default=lambda *a: 'draft')

    _sql_constraints = [('name_uniq', 'unique(name)', 'Unique')]


    @api.model
    def create(self, vals):
        sequence = self.env['ir.sequence'].next_by_code('oeh.medical.triage')
        vals['name'] = sequence or "/"
        return super(OeHealthTriage, self).create(vals)

    @api.multi
    def action_draft(self):
        return self.write({'state': 'draft'})
        

    @api.multi
    def action_start(self):
       return self.write({'state': 'inprogress'})

    @api.multi
    def action_complete(self):
       
       return self.write({'state': 'complete'})

    @api.multi
    def print_triage_report(self):
        return self.env['report'].get_action(self, 'oehealth_extra_addons.report_oeh_medical_triage')

class OeHealthTriageDash(models.TransientModel):
    _name = 'oeh.medical.triage.dash'
    

  
    tt =   fields.Reference([('oeh.medical.health.center','Health Center'),('oeh.medical.labtest.types','Lab Test'),('oeh.medical.imaging.test.type','Imaging')])

    @api.multi
    def call_next(self):
        
        return True